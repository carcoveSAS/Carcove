@echo off
echo ====================================================
echo   Iniciando Servidor Local para CARCOVE S.A.S.
echo ====================================================
echo.
echo Dado que la aplicacion usa arquitectura modular (ES Modules),
echo no se puede abrir directamente con doble clic por seguridad (CORS).
echo.
echo Abriendo servidor local...
echo.

npx http-server -p 8080 -o
pause
